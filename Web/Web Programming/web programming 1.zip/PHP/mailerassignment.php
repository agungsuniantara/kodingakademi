<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="phpmailer.php" method="post">
        <label for="email">Email : </label>
        <input type="email" id="email" name="email"> <br>
        <label for="pesan">Pesan : </label>
        <input type="text" id="pesan" name="pesan"> <br>
        <input type="submit" value="submit">
    </form>
</body>

</html>