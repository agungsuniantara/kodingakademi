import csv
import os

# ==========================================
# KONFIGURASI NAMA FILE
# ==========================================
FILE_KARYAWAN = "karyawan.csv"
FILE_BARANG = "barang.csv"
FILE_TRANSAKSI = "transaksi.csv"
FILE_DETAIL = "detail_transaksi.csv"

# ==========================================
# 1. INISIALISASI DATABASE (FILE CSV)
# ==========================================
def inisialisasi_file():
    """
    Fungsi ini dipanggil saat aplikasi pertama kali dijalankan.
    Jika file CSV belum ada, fungsi ini akan membuatnya beserta baris header.
    """
    # Buat file karyawan.csv jika belum ada (sekaligus beri 1 akun default)
    if not os.path.exists(FILE_KARYAWAN):
        with open(FILE_KARYAWAN, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id_karyawan", "username", "password", "nama", "role"])
            writer.writerow(["KRY001", "admin", "admin123", "Administrator", "Admin"])
            writer.writerow(["KRY002", "kasir", "kasir123", "Petugas Kasir", "Kasir"])
            writer.writerow(["KRY005", "manager", "manager123", "Manager Utama", "Manager"])
            
    # Buat file barang.csv
    if not os.path.exists(FILE_BARANG):
        with open(FILE_BARANG, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id_barang", "nama_barang", "harga", "stok"])
            
    # Buat file transaksi.csv
    if not os.path.exists(FILE_TRANSAKSI):
        with open(FILE_TRANSAKSI, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id_transaksi", "waktu", "id_karyawan", "total_belanja", "uang_bayar"])
            
    # Buat file detail_transaksi.csv
    if not os.path.exists(FILE_DETAIL):
        with open(FILE_DETAIL, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["id_transaksi", "id_barang", "qty", "subtotal"])


# ==========================================
# 2. FUNGSI OTENTIKASI (KARYAWAN)
# ==========================================
def validasi_login(username, password):
    """
    Mengecek apakah username dan password cocok dengan data di karyawan.csv.
    Mengembalikan Dictionary data user jika sukses, atau None jika gagal.
    """
    inisialisasi_file() # Pastikan file ada sebelum dibaca
    
    with open(FILE_KARYAWAN, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["username"] == username and row["password"] == password:
                return {
                    "id": row["id_karyawan"],
                    "nama": row["nama"],
                    "role": row["role"]
                }
    return None # Jika tidak ada yang cocok


# ==========================================
# 3. FUNGSI MANAJEMEN BARANG (CRUD DASAR)
# ==========================================
def ambil_semua_barang():
    """Membaca seluruh data barang dan mengembalikannya dalam bentuk List of Dictionaries."""
    inisialisasi_file()
    daftar_barang = []
    
    with open(FILE_BARANG, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Konversi harga dan stok menjadi integer agar bisa dihitung nantinya
            row["harga"] = int(row["harga"])
            row["stok"] = int(row["stok"])
            daftar_barang.append(row)
            
    return daftar_barang

def tambah_barang_baru(id_barang, nama, harga, stok):
    """Menambahkan satu baris data barang baru ke CSV."""
    with open(FILE_BARANG, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([id_barang, nama, harga, stok])


# ==========================================
# 4. FUNGSI TRANSAKSI & INVENTORY LOGIC
# ==========================================
def kurangi_stok_barang(id_barang, jumlah_beli):
    """
    Logika overwrite:
    1. Baca semua isi file barang.csv ke dalam List.
    2. Cari id_barang yang sesuai, kurangi stoknya.
    3. Tulis ulang seluruh isi List kembali ke barang.csv.
    """
    semua_barang = []
    
    # Langkah 1 & 2: Baca dan modifikasi di memori
    with open(FILE_BARANG, "r") as f:
        reader = csv.reader(f)
        header = next(reader) # Simpan baris header
        semua_barang.append(header)
        
        for row in reader:
            row_id = row[0]
            stok_lama = int(row[3])
            
            if row_id == id_barang:
                stok_baru = stok_lama - jumlah_beli
                row[3] = str(stok_baru) # Update data stok (jadikan string kembali)
                
            semua_barang.append(row)
            
    # Langkah 3: Tulis ulang (overwrite) file
    with open(FILE_BARANG, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(semua_barang)


def simpan_transaksi_lengkap(id_transaksi, waktu, id_karyawan, total_belanja, uang_bayar, keranjang):
    """
    Fungsi ini sangat penting (bersifat Atomik).
    Mengeksekusi penulisan nota, penulisan detail item, dan pengurangan stok secara berurutan.
    Parameter 'keranjang' diasumsikan sebagai List yang berisi data: [id_barang, qty, subtotal]
    """
    # 1. Simpan Header Transaksi
    with open(FILE_TRANSAKSI, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([id_transaksi, waktu, id_karyawan, total_belanja, uang_bayar])
        
    # 2. Simpan Detail Transaksi & Kurangi Stok
    with open(FILE_DETAIL, "a", newline="") as f:
        writer = csv.writer(f)
        
        for item in keranjang:
            id_barang = item[0]
            qty = item[1]
            subtotal = item[2]
            
            # Catat item apa saja yang dibeli ke detail_transaksi.csv
            writer.writerow([id_transaksi, id_barang, qty, subtotal])
            
            # Panggil fungsi pengurangan stok
            kurangi_stok_barang(id_barang, qty)


# ==========================================
# 5. FUNGSI MANAJEMEN KARYAWAN (CRUD)
# ==========================================
def ambil_semua_karyawan():
    inisialisasi_file()
    daftar_karyawan = []
    with open(FILE_KARYAWAN, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            daftar_karyawan.append(row)
    return daftar_karyawan

def tambah_karyawan_baru(id_karyawan, username, password, nama, role):
    with open(FILE_KARYAWAN, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([id_karyawan, username, password, nama, role])

def edit_karyawan(id_karyawan, username_baru, password_baru, nama_baru, role_baru):
    semua_karyawan = []
    with open(FILE_KARYAWAN, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        semua_karyawan.append(header)
        for row in reader:
            if row[0] == id_karyawan:
                row[1] = username_baru
                row[2] = password_baru
                row[3] = nama_baru
                row[4] = role_baru
            semua_karyawan.append(row)
    with open(FILE_KARYAWAN, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(semua_karyawan)

def hapus_karyawan(id_karyawan):
    semua_karyawan = []
    with open(FILE_KARYAWAN, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        semua_karyawan.append(header)
        for row in reader:
            if row[0] != id_karyawan:
                semua_karyawan.append(row)
    with open(FILE_KARYAWAN, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(semua_karyawan)