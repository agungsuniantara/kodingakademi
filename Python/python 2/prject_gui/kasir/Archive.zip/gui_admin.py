import tkinter as tk
from tkinter import ttk, messagebox
import core_db
import session

def bersihkan_window(window):
    for widget in window.winfo_children():
        widget.destroy()

def muat_data_tabel(tree):
    for item in tree.get_children():
        tree.delete(item)
        
    daftar_barang = core_db.ambil_semua_barang()
    
    for barang in daftar_barang:
        tree.insert("", tk.END, values=(
            barang["id_barang"], 
            barang["nama_barang"], 
            f"Rp {barang['harga']}",
            barang["stok"]
        ))

def proses_tambah_barang(entries, tree):
    id_barang = entries['id'].get().strip()
    nama = entries['nama'].get().strip()
    harga = entries['harga'].get().strip()
    stok = entries['stok'].get().strip()
    
    if not id_barang or not nama or not harga or not stok:
        messagebox.showerror("Error", "Semua kolom form harus diisi!")
        return
        
    if not harga.isdigit() or not stok.isdigit():
        messagebox.showerror("Error", "Harga dan Stok harus berupa angka yang valid!")
        return
        
    core_db.tambah_barang_baru(id_barang, nama, int(harga), int(stok))
    messagebox.showinfo("Sukses", "Data barang berhasil ditambahkan ke sistem!")
    
    entries['id'].delete(0, tk.END)
    entries['nama'].delete(0, tk.END)
    entries['harga'].delete(0, tk.END)
    entries['stok'].delete(0, tk.END)
    
    muat_data_tabel(tree)

def tampilkan_halaman(window, fungsi_logout):
    bersihkan_window(window)
    
    nama_admin = session.current_user["nama"] if session.current_user else "Administrator"
    
    header_frame = tk.Frame(window, pady=15)
    header_frame.pack(fill="x")
    tk.Label(header_frame, text="DASHBOARD ADMIN - INVENTORY", font=("Arial", 18, "bold")).pack()
    tk.Label(header_frame, text=f"Selamat Bekerja, {nama_admin}", font=("Arial", 12)).pack()
    
    main_frame = tk.Frame(window, padx=20, pady=20)
    main_frame.pack(fill="both", expand=True)
    
    form_frame = tk.Frame(main_frame, width=300)
    form_frame.pack(side="left", fill="y", padx=(0, 20))
    
    tk.Label(form_frame, text="Tambah Barang Baru", font=("Arial", 14, "bold")).pack(anchor="w", pady=(0, 15))
    
    tk.Label(form_frame, text="Kode / ID Barang").pack(anchor="w")
    entry_id = tk.Entry(form_frame, font=("Arial", 12), width=25)
    entry_id.pack(pady=(0, 10))
    
    tk.Label(form_frame, text="Nama Barang").pack(anchor="w")
    entry_nama = tk.Entry(form_frame, font=("Arial", 12), width=25)
    entry_nama.pack(pady=(0, 10))
    
    tk.Label(form_frame, text="Harga (Rp)").pack(anchor="w")
    entry_harga = tk.Entry(form_frame, font=("Arial", 12), width=25)
    entry_harga.pack(pady=(0, 10))
    
    tk.Label(form_frame, text="Stok Awal").pack(anchor="w")
    entry_stok = tk.Entry(form_frame, font=("Arial", 12), width=25)
    entry_stok.pack(pady=(0, 20))
    
    entries = {'id': entry_id, 'nama': entry_nama, 'harga': entry_harga, 'stok': entry_stok}
    
    btn_simpan = tk.Button(form_frame, text="SIMPAN BARANG", font=("Arial", 12, "bold"),
                           command=lambda: proses_tambah_barang(entries, tree_barang))
    btn_simpan.pack(fill="x", pady=5)
    
    btn_logout = tk.Button(form_frame, text="LOGOUT", font=("Arial", 12, "bold"),
                           command=fungsi_logout)
    btn_logout.pack(side="bottom", fill="x", pady=20)
    
    table_frame = tk.Frame(main_frame)
    table_frame.pack(side="right", fill="both", expand=True)
    
    tk.Label(table_frame, text="Master Data Inventaris", font=("Arial", 14, "bold")).pack(anchor="w", pady=(0, 10))
    
    kolom = ("ID", "Nama", "Harga", "Stok")
    tree_barang = ttk.Treeview(table_frame, columns=kolom, show="headings", height=15)
    
    tree_barang.heading("ID", text="ID Barang")
    tree_barang.column("ID", width=100, anchor="center")
    
    tree_barang.heading("Nama", text="Nama Barang")
    tree_barang.column("Nama", width=250, anchor="w")
    
    tree_barang.heading("Harga", text="Harga Satuan")
    tree_barang.column("Harga", width=120, anchor="e")
    
    tree_barang.heading("Stok", text="Stok")
    tree_barang.column("Stok", width=80, anchor="center")
    
    scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree_barang.yview)
    tree_barang.configure(yscrollcommand=scrollbar.set)
    
    scrollbar.pack(side="right", fill="y")
    tree_barang.pack(side="left", fill="both", expand=True)
    
    muat_data_tabel(tree_barang)
