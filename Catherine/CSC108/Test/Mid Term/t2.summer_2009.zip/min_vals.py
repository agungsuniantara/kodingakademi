def min_vals (d1, d2):
  '''d1 and d2 are dictionaries that have exactly the same set of keys,
  and whose values are integers.
  Return a new dictionary that has the same keys as those in d1 or d2,
  and whose values are the smaller of the values associated with the key in d1 or d2.  
  For example, min_vals ({1:3, 2:5}, {1:2, 2:-4}) returns 
  {1:2, 2:-4}.
  '''
  
  new_dict = {}
  for k in d1:
    new_dict[k] = min(d1[k], d2[k])
  return new_dict
