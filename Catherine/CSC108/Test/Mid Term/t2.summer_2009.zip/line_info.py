def line_info (f):
  '''Given open file object f, return a tuple whose first component
  is the number of lines in f, and whose second component is the
  total number of characters, not including newlines, in f.
  '''
  
  lines = 0
  chars = 0
  for line in f:
    lines += 1
    if line[-1] == '\n':
      line = line[:-1]
    chars += len(line)
  return lines, chars
      